package com.example.touzouz_adnane_projet;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {
    private TextView welcomeTextView, nameTextView, emailTextView, filiereTextView, passwordTextView, phoneTextView, sexeTextView;
    private String name, email, filiere, password, phone, sexe;
    private CircleImageView imageView;
    private FirebaseAuth authProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        welcomeTextView = findViewById(R.id.textView_show_welcome);
        nameTextView = findViewById(R.id.textView_show_full_name);
        emailTextView = findViewById(R.id.textView_show_email);
        filiereTextView = findViewById(R.id.textView_show_filiere);
        passwordTextView = findViewById(R.id.textView_show_password);
        phoneTextView = findViewById(R.id.textView_show_phone);
        sexeTextView = findViewById(R.id.textView_show_sexe);
        imageView = findViewById(R.id.imageView_profile_dp);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, UploadProfilePicActivity.class);
                startActivity(intent);
            }
        });

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        if (firebaseUser == null){
            Toast.makeText(ProfileActivity.this, "Error , resayer dans un autre moment", Toast.LENGTH_SHORT).show();
        } else {
            showUserProfile(firebaseUser);
        }

        Button updateButton = findViewById(R.id.button_update_profile_details);
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, UpdateProfileActivity.class);
                intent.putExtra("password", password);
                startActivity(intent);
            }
        });

        Button homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent9 = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(intent9);
                finish();
            }
        });

    }

    private void showUserProfile(FirebaseUser firebaseUser) {
        String userID = firebaseUser.getUid();
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Registred Users");
        referenceProfile.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ReadWriteUserDetails readUserDetails = snapshot.getValue(ReadWriteUserDetails.class);
                if(readUserDetails != null){
                    Intent intent = getIntent();
                    name = readUserDetails.nom;
                    email = firebaseUser.getEmail();
                    filiere = readUserDetails.filiere;
                    phone = readUserDetails.phone;
                    sexe = readUserDetails.sexe;
                    password = intent.getStringExtra("password");

                    welcomeTextView.setText("Bonjour "+name+" !");
                    nameTextView.setText(name);
                    emailTextView.setText(email);
                    filiereTextView.setText(filiere);
                    phoneTextView.setText(phone);
                    sexeTextView.setText(sexe);

                    Uri uri = firebaseUser.getPhotoUrl();
                    Picasso.get().load(uri).into(imageView);
                } else {
                    Toast.makeText(ProfileActivity.this, "Error , resayer dans un autre moment", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this, "Error , resayer dans un autre moment", Toast.LENGTH_SHORT).show();
            }
        });
    }
}