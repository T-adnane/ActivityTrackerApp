package com.example.touzouz_adnane_projet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private EditText signupEmail, signupPassword, signupRepassword, signupNom, signupPhone, signupFiliere;
    private RadioGroup signupradioGroupsexe;
    private RadioButton signupradioGroupsexeSelected;
    private Button signupButton;
    private TextView loginRedirectText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        auth = FirebaseAuth.getInstance();
        signupEmail = findViewById(R.id.signup_email);
        signupPassword = findViewById(R.id.signup_password);
        signupRepassword = findViewById(R.id.signup_repassword);
        signupNom = findViewById(R.id.signup_nom);
        signupPhone = findViewById(R.id.signup_phone);
        signupFiliere = findViewById(R.id.signup_filiere);
        signupButton = findViewById(R.id.signup_button);
        loginRedirectText = findViewById(R.id.loginRedirectText);
        signupradioGroupsexe = findViewById(R.id.radio_group_register_gender);
        signupradioGroupsexe.clearCheck();

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                String user = signupEmail.getText().toString().trim();
                String pass = signupPassword.getText().toString().trim();
                String repass = signupRepassword.getText().toString().trim();
                String nom = signupNom.getText().toString().trim();
                String phone = signupPhone.getText().toString().trim();
                String filiere = signupFiliere.getText().toString().trim();
                int selectedGenderId = signupradioGroupsexe.getCheckedRadioButtonId();
                signupradioGroupsexeSelected = findViewById(selectedGenderId);
                String sexe;

                if(selectedGenderId == -1) {
                    Toast.makeText(SignUpActivity.this, "Select your gender", Toast.LENGTH_SHORT).show();
                }
                if (user.isEmpty()){
                    signupEmail.setError("remplir Email");
                }
                if (pass.isEmpty()){
                    signupPassword.setError("remplir Password");
                }
                if (repass.isEmpty()){
                    signupRepassword.setError("confirmer Password");
                }
                if (!pass.equals(repass)){
                    signupRepassword.setError("vérifier le mot de passe");
                }
                if (nom.isEmpty()){
                    signupNom.setError("remplir Nom");
                }
                if (phone.isEmpty()){
                    signupPhone.setError("remplir Téléphone");
                }
                if (filiere.isEmpty()){
                    signupFiliere.setError("remplir filière");
                }
                else {
                    sexe = signupradioGroupsexeSelected.getText().toString();
                    auth.createUserWithEmailAndPassword(user, pass).addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                FirebaseUser firebaseUser = auth.getCurrentUser();
                                ReadWriteUserDetails writeUserDetails = new ReadWriteUserDetails(nom, phone, filiere, sexe);
                                DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Registred Users");
                                referenceProfile.child(firebaseUser.getUid()).setValue(writeUserDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(SignUpActivity.this, "SignUp Successful", Toast.LENGTH_SHORT).show();
                                            finish();
                                        }
                                        else {
                                            Toast.makeText(SignUpActivity.this, "SignUp Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                            }
                            else{
                                Toast.makeText(SignUpActivity.this, "SignUp Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            }
        });
    }
}