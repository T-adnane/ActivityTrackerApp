package com.example.touzouz_adnane_projet;

public class ReadWriteUserDetails {
    public String nom, phone, filiere, sexe;

    public ReadWriteUserDetails() {
    };

    public ReadWriteUserDetails(String nom, String phone, String filiere, String sexe) {
        this.nom = nom;
        this.phone = phone;
        this.filiere = filiere;
        this.sexe = sexe;
    }
}